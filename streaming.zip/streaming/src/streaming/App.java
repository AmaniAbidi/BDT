package streaming;
import java.util.Arrays;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import scala.Tuple2;

 public class App {
	public static void main (String [] args )throws InterruptedException {
		Logger.getLogger("org.apache").setLevel(Level.WARN);
		SparkConf conf=new SparkConf().setAppName("task").setMaster("local[6]")	;
        JavaStreamingContext jsc = new JavaStreamingContext(conf, new Duration(1000));
        JavaReceiverInputDStream<String> data=jsc.socketTextStream("localhost",9999);
        JavaDStream < String>d= data.flatMap(data1 -> Arrays.asList(data1.split(" ")));
        JavaPairDStream<String, Long> d2=  d.mapToPair(data2 -> new Tuple2<String, Long> (data2, 1L));
        
        JavaPairDStream<String, Long> newdata=d2.reduceByKey ((x , y )-> x+y);
        newdata.print(); 
        jsc.start();
        jsc.awaitTermination();
}
}